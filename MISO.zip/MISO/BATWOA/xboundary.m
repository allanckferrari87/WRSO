ub=1;
lb=-1;
            Flag4ub = Positions(i,4:dim)>limi;
            Flag4lb = Positions(i,4:dim)<-limi;
            Positions(i,4:dim)=(Positions(i,4:dim).*(~(Flag4ub+Flag4lb)))+(limi).*Flag4ub+(-limi).*Flag4lb;

            Flag4ub = Positions(i,1:3)>ub;
            Flag4lb = Positions(i,1:3)<lb;
            Positions(i,1:3)=(Positions(i,1:3).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;