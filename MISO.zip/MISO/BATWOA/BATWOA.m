function [Leader_pos,Leader_score]=BATWOA(U,Y)
% initialize alpha, beta, and delta_pos
Max_iter = 100;
SearchAgents_no = 100;
dim = 27;


Leader_pos=zeros(1,dim);
Leader_score=inf; %change this to -inf for maximization problems

%Initialize the positions of search agents
%Positions=2*rand(SearchAgents_no,dim) - 1;%população inicial gerada
init_population;
%bat algorithm addition
Qmin=0;         % Frequency minimum
Qmax=2;         % Frequency maximum
Q=zeros(SearchAgents_no,1);   % Frequency
v=zeros(SearchAgents_no,dim);   % Velocities
r=0.5;
A1=0.5;
t=0;% Loop counter
% summ=0;
% Main loop
fitness = zeros(1,SearchAgents_no);
while t<Max_iter
  
    for i=1:SearchAgents_no      
       %  xboundary
        % Calculate objective function for each search agent
        [Ye,fitness(i)] = fun_completo(Positions(i,:)',U,Y,1);
        % Update the leader
        if fitness(i)<Leader_score % Change this to > for maximization problem
            Leader_score=fitness(i); % Update alpha
            Leader_pos=Positions(i,:);
        end 
    end
    
    a=2-t*((2)/Max_iter); % a decreases linearly fron 2 to 0 in Eq. (2.3)
    
    % a2 linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
    a2=-1+t*((-1)/Max_iter);
    
    % Update the Position of search agents 
    for i=1:SearchAgents_no 
        r1=rand(); % r1 is a random number in [0,1]
        r2=rand(); % r2 is a random number in [0,1]
        
        A=2*a*r1-a;  % Eq. (2.3) in the paper
        C=2*r2;      % Eq. (2.4) in the paper
        
        
        b=1;               %  parameters in Eq. (2.5)
        l=(a2-1)*rand+1;   %  parameters in Eq. (2.5)
        
       p = rand();        % p in Eq. (2.6)
       
        for j=1:dim
            
            if p<0.5   
                
                if abs(A)>=1

                             rand_leader_index = floor(SearchAgents_no*rand()+1);
                             X_rand = Positions(rand_leader_index, :);
                             Q(i)=Qmin+(Qmin-Qmax)*rand;
                             v(i,:)=v(i,j)+(X_rand(j)-Leader_pos(j))*Q(i);
                            z(i,:)= Positions(i,:)+ v(i,:);
                            
                            
                            %%%% problem 
                                if rand>r
                                % The factor 0.001 limits the step sizes of random walks 
                                z (i,:)=Leader_pos(j)+0.001*randn(1,dim);
                                end
                                     % Evaluate new solutions
                                    [Ye,Fnew] = fun_completo(z(i,:)',U,Y,1);
                                     % Update if the solution improves, or not too loud
                                    if (Fnew<=fitness(i)) && (rand<A1) 
                                       Positions(i,:)=z(i,:);
                                        fitness(i)=Fnew;
                                    end

                elseif abs(A)<1
                             Q(i)=Qmin+(Qmin-Qmax)*rand;
                             v(i,:)=v(i,j)+(Positions(i,:)-Leader_pos(j))*Q(i);
                            z(i,:)= Positions(i,:)+ v(i,:);
                          
                            %%%% problem 
                                if rand>r
                                % The factor 0.001 limits the step sizes of random walks 
                                z (i,:)=Leader_pos(j)+0.001*randn(1,dim);
                                end
                                     % Evaluate new solutions
                                    [Ye,Fnew] = fun_completo(z(i,:)',U,Y,1);
                                     % Update if the solution improves, or not too loud
                                    if (Fnew<=fitness(i)) && (rand<A1) 
                                       Positions(i,:)=z(i,:);
                                        fitness(i)=Fnew;
                                    end
                end
                
            elseif p>=0.5
              
                distance2Leader=abs(Leader_pos(j)-Positions(i,j));
                % Eq. (2.5)
                Positions(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Leader_pos(j);
            end
            
        end
    end
    t=t+1;


end
end


























