%% Comando Executar %%
clear all
clc

load taruma.txt
% Estima��o 1
est = 827:941;
%est = 700:780;
Ue = taruma(est,1:6)';
Ye = taruma(est,10)'/1000;
%valida��o
val = 960:1040;
Uv = taruma(val,1:6)';
Yv = taruma(val,10)'/1000;


figure(1)
subplot(411)
plot(Ue(1,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_1')
xlim([0 115]);
ylim([0 420]);
subplot(412)
plot(Ue(2,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_2')
xlim([0 115]);
ylim([0 420]);
subplot(413)
plot(Ue(3,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_3')
xlim([0 115]);
ylim([0 420]);
subplot(414)
plot(Ue(4,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_4')
xlim([0 115]);
ylim([0 420]);

figure(2)
subplot(411)
plot(Ue(4,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_4')
xlim([0 115]);
ylim([0 420]);
subplot(412)
plot(Ue(5,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_5')
xlim([0 115]);
ylim([0 420]);
subplot(413)
plot(Ue(6,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_6')
xlim([0 115]);
ylim([0 420]);
subplot(414)
plot(Ye,'k')
xlabel('Tempo (horas)')
ylabel('Vaz�o (m�/s)')
title('y')
xlim([0 115]);
ylim([0 2]);




figure(3)
subplot(411)
plot(Uv(1,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_1')
xlim([0 80]);
ylim([0 420]);
subplot(412)
plot(Uv(2,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_2')
xlim([0 80]);
ylim([0 420]);
subplot(413)
plot(Uv(3,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_3')
xlim([0 80]);
ylim([0 420]);
subplot(414)
plot(Uv(4,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_4')
xlim([0 80]);
ylim([0 420]);

figure(4)
subplot(411)
plot(Uv(4,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_4')
xlim([0 80]);
ylim([0 420]);
subplot(412)
plot(Uv(5,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_5')
xlim([0 80]);
ylim([0 420]);
subplot(413)
plot(Uv(6,:),'k')
xlabel('Tempo (horas)')
ylabel('Corrente el�trica (A)')
title('u_6')
xlim([0 80]);
ylim([0 420]);
subplot(414)
plot(Yv,'k')
xlabel('Tempo (horas)')
ylabel('Vaz�o (m�/s)')
title('y')
xlim([0 80]);
ylim([0 2]);